chmod 755 CoA_AI.x86_64
