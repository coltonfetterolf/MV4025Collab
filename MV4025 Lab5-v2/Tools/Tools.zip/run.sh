while [ -f "todo.txt" ]; do
./CoA_AI.x86_64;
done
