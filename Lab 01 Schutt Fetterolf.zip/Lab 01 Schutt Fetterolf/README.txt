Thomas Schutt
Colton Fetterolf
MV 4025 Lab 01
19 July 2019

We were successful in getting the entities to follow the A* path and avoid the wall.  All previous functionality of the sim remains the same.  To enable viewing the grid mesh when playing the game, the 'Show Graphs' radio button in the 'Graphs' component of the A* object needs to be selected.